#include <stdio.h>
#include <math.h>

int* is_Prime(int input) {
    int i, j;
    int result;
    int count = 1;
    int* getNum;

    getNum = (int*)malloc(sizeof(int) * input);

    for (i = 2; i <= input; i++) {
        if (i == 2) {
            getNum[count] = i;
            count++;
        }
        if (i == 3) {
            getNum[count] = i;
            count++;
        }

        for (j = 2; j <= (int)sqrt(i); j++) {
            if (i % j == 0) {
                /* �Ҽ� �ƴ� */
                break;
            }
            else {
                if (j == (int)sqrt(i)) {
                    // sqrt(i) ���� �����µ��� �ȳ�����, �� �Ҽ�
                    getNum[count] = i;
                    count++;
                }

            }


        }
    }

    getNum[0] = count;

    return getNum;
}

void main2() {

    int n, i;
    int first;
    int* result;

    printf("�Ҽ��� ���� ������ �Է����ּ���.\n");
    scanf_s("%d", &n);

    result = (int)malloc(sizeof(int) * n);

    result = is_Prime(n);


    for (i = 1; i < result[0]; i++) {
        printf("%d\n", result[i]);
    }

}


//�Ҽ� �Ǵ� �ҽ�//
/*
main()
{
    int n;
    int i;
    int count = 0;

    printf("���ڸ� �Է��ϼ��� :");
    scanf_s("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (count > 2)
        {
            break;
        }

        if (n % 1 == 0)
        {
            count += 1;
        }
    }
    if (count == 2)
    {
        printf("%d�� �Ҽ��Դϴ�.", n);
    }
    else
    {
        printf("%d�� �Ҽ��� �ƴմϴ�.", n);
    }
    printf("\n");
}


*/
/*
int prime[51];

int main(void)
{
	prime[1] = 1;
	for (int i = 2; i * i <= 50; i++)
	{
		if (!prime[i])
		{
			for (int k = i * i; k <= 50; k += i)
				prime[k] = 1;
		}
	}

	for (int num = 1; num <= 50; num++)
		if (!prime[num]) printf("%d is prime\n", num);

	return 0;
}
*/


/* �Ҽ��Ǻ� only
int isPrime(int n, int* a, int* b);

void main()
{
    int n;
    int a, b;



    printf("���� ���� n�� �Է��Ͻÿ�:");
    scanf_s("%d", &n);



    if (isPrime(n, &a, &b) == 1)
    {
        printf("Prime Number ");
    }
    else if (isPrime(n, &a, &b) == 0)
    {
        printf("%d %d ", a, b);
    }
    else;
    {
        printf("Try Again ");
    }
}



int isPrime(int n, int* a, int* b)
{
    int i, j;

    for (i = 2; i < n; i++)
    {
        if (n % i == 0)
        {
            if ((n != 2) && (n % 2 == 0))
            {
                return 0;                   
            }

        }
        else
        {
            return 1;
        }
    }

}
*/

/*
#define MAX_NUM n

int main()
{
    int num, i, n;

    scanf_s("%d", &n);

    for (num = 2; num <= MAX_NUM; num++) {
        for (i = 2; i < num; i++) {

        }
    }
}
*/